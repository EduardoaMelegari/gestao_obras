export function VistoriaView() {
  return (
    <div className="flex-1 flex items-center justify-center bg-[#0a0a0a]">
      <div className="text-center">
        <h2 className="text-white text-3xl font-semibold mb-4">Vistoria</h2>
        <p className="text-gray-400">Conteúdo de vistoria em desenvolvimento</p>
      </div>
    </div>
  );
}
