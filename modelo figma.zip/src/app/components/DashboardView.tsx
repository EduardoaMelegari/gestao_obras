export function DashboardView() {
  return (
    <div className="flex-1 flex items-center justify-center bg-[#0a0a0a]">
      <div className="text-center">
        <h2 className="text-white text-3xl font-semibold mb-4">Dashboard</h2>
        <p className="text-gray-400">Conteúdo do dashboard em desenvolvimento</p>
      </div>
    </div>
  );
}
