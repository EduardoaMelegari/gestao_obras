import { Button } from './ui/button';

interface Project {
  id: number;
  cidade: string;
  pasta: string;
  categoria: string;
  cliente: string;
  diasAposConf: number;
  status: string;
  obs: string;
  rowColor?: string;
}

interface ProjectsTableProps {
  projects: Project[];
  title: string;
}

export function ProjectsTable({ projects, title }: ProjectsTableProps) {
  const getStatusColor = (status: string) => {
    if (status.includes('Falta ART')) return 'text-yellow-400';
    if (status.includes('Não Iniciado')) return 'text-red-400';
    return 'text-gray-300';
  };

  const getObsColor = (obs: string) => {
    if (obs.includes('FALTA ART')) return 'text-yellow-400';
    return 'text-gray-300';
  };

  return (
    <div className="flex-1 bg-[#0a0a0a] p-6">
      <div className="bg-[#1f2937] rounded-lg overflow-hidden">
        <div className="bg-[#1e3a5f] px-4 py-3 flex items-center justify-between">
          <h2 className="text-white font-semibold">{title}</h2>
          <Button 
            variant="outline" 
            size="sm"
            className="bg-transparent border-white text-white hover:bg-white/10"
          >
            Exportar CSV
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#374151] text-white text-sm">
                <th className="px-4 py-3 text-left font-semibold">#</th>
                <th className="px-4 py-3 text-left font-semibold">CIDADE</th>
                <th className="px-4 py-3 text-left font-semibold">PASTA</th>
                <th className="px-4 py-3 text-left font-semibold">CATEGORIA</th>
                <th className="px-4 py-3 text-left font-semibold">CLIENTE</th>
                <th className="px-4 py-3 text-left font-semibold">DIAS APÓS CONF.</th>
                <th className="px-4 py-3 text-left font-semibold">STATUS</th>
                <th className="px-4 py-3 text-left font-semibold">OBS</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project, index) => (
                <tr
                  key={project.id}
                  className={`border-b border-gray-700 text-sm ${
                    project.rowColor === 'yellow' 
                      ? 'bg-yellow-600' 
                      : project.rowColor === 'red' 
                      ? 'bg-red-600' 
                      : index % 2 === 0 
                      ? 'bg-[#2d3748]' 
                      : 'bg-[#374151]'
                  }`}
                >
                  <td className="px-4 py-3 text-white">{project.id}.</td>
                  <td className="px-4 py-3 text-white">{project.cidade}</td>
                  <td className="px-4 py-3 text-white">{project.pasta}</td>
                  <td className="px-4 py-3 text-white">{project.categoria}</td>
                  <td className="px-4 py-3 text-white">{project.cliente}</td>
                  <td className="px-4 py-3 text-white">{project.diasAposConf}</td>
                  <td className={`px-4 py-3 ${getStatusColor(project.status)}`}>
                    {project.status}
                  </td>
                  <td className={`px-4 py-3 ${getObsColor(project.obs)}`}>
                    {project.obs}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
