import { LayoutDashboard, FolderKanban, Eye } from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
}

export function Sidebar({ currentView, onViewChange }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'projetos', label: 'Projetos', icon: FolderKanban },
    { id: 'vistoria', label: 'Vistoria', icon: Eye },
  ];

  return (
    <div className="w-64 bg-[#1a1a1a] h-screen flex flex-col">
      <div className="p-4 border-b border-gray-800">
        <button className="text-white text-xl">
          ←
        </button>
      </div>
      
      <div className="p-4">
        <h2 className="text-white text-sm font-semibold mb-4">GESTÃO DE PROJETOS</h2>
      </div>

      <nav className="flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-6 py-3 text-left transition-colors ${
                isActive 
                  ? 'bg-orange-500 text-white' 
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <Icon className="size-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
