import { Search } from 'lucide-react';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

interface TopBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
}

export function TopBar({ searchTerm, onSearchChange }: TopBarProps) {
  return (
    <div className="bg-[#1a1a1a] border-b border-gray-800 px-6 py-3 flex items-center gap-4">
      <div className="flex items-center gap-2 flex-1">
        <span className="text-gray-400 text-sm">Buscar:</span>
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Cliente ou Cidade"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
          />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <span className="text-gray-400 text-sm">Cidade:</span>
        <Select defaultValue="todos">
          <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas</SelectItem>
            <SelectItem value="sorriso">Sorriso</SelectItem>
            <SelectItem value="lucas">Lucas do Rio Verde</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-2">
        <span className="text-gray-400 text-sm">Vendedor:</span>
        <Select defaultValue="todos">
          <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
