import { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { ProjectsTable } from './ProjectsTable';
import { TopBar } from './TopBar';
import { 
  projectsInProgress, 
  projectsCompleted, 
  projectsDelayed, 
  projectsPending 
} from '../data/projectsData';

export function ProjectsView() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('andamento');

  const filterProjects = (projects: any[]) => {
    if (!searchTerm) return projects;
    
    return projects.filter(project => 
      project.cliente.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.cidade.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  const allProjects = [
    ...projectsInProgress,
    ...projectsCompleted,
    ...projectsDelayed,
  ].sort((a, b) => a.id - b.id);

  return (
    <div className="flex-1 flex flex-col">
      <TopBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
      
      <div className="flex-1 bg-[#0a0a0a] p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-4 bg-[#1a1a1a] border border-gray-700">
            <TabsTrigger value="andamento" className="data-[state=active]:bg-blue-600">
              Projetos em Andamento
            </TabsTrigger>
            <TabsTrigger value="concluidos" className="data-[state=active]:bg-green-600">
              Projetos Concluídos
            </TabsTrigger>
            <TabsTrigger value="atrasados" className="data-[state=active]:bg-red-600">
              Projetos Atrasados
            </TabsTrigger>
            <TabsTrigger value="pendentes" className="data-[state=active]:bg-yellow-600">
              Projetos Pendentes (ART)
            </TabsTrigger>
            <TabsTrigger value="todos" className="data-[state=active]:bg-purple-600">
              Todos os Projetos
            </TabsTrigger>
          </TabsList>

          <TabsContent value="andamento">
            <ProjectsTable 
              projects={filterProjects(projectsInProgress)} 
              title="PROJETOS EM ANDAMENTO"
            />
          </TabsContent>

          <TabsContent value="concluidos">
            <ProjectsTable 
              projects={filterProjects(projectsCompleted)} 
              title="PROJETOS CONCLUÍDOS"
            />
          </TabsContent>

          <TabsContent value="atrasados">
            <ProjectsTable 
              projects={filterProjects(projectsDelayed)} 
              title="PROJETOS ATRASADOS"
            />
          </TabsContent>

          <TabsContent value="pendentes">
            <ProjectsTable 
              projects={filterProjects(projectsPending)} 
              title="PROJETOS PENDENTES - AGUARDANDO ART"
            />
          </TabsContent>

          <TabsContent value="todos">
            <ProjectsTable 
              projects={filterProjects(allProjects)} 
              title="TODOS OS PROJETOS"
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
