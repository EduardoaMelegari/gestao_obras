import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { ProjectsView } from './components/ProjectsView';
import { DashboardView } from './components/DashboardView';
import { VistoriaView } from './components/VistoriaView';

export default function App() {
  const [currentView, setCurrentView] = useState('projetos');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardView />;
      case 'projetos':
        return <ProjectsView />;
      case 'vistoria':
        return <VistoriaView />;
      default:
        return <ProjectsView />;
    }
  };

  return (
    <div className="size-full flex bg-[#0a0a0a]">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      {renderView()}
    </div>
  );
}